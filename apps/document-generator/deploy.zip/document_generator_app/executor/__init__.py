"""
Executor package for Document Generator.
"""

__all__ = ["generate_document"]
from .runner import generate_document
