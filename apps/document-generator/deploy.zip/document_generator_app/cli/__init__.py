"""
CLI package for Document Generator.
"""

__all__ = ["app"]
from .main import app
