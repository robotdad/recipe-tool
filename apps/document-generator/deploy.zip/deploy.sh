#!/bin/bash
# Azure deployment script for document-generator

echo "Creating deployment package..."
python3 -m zipfile -c deploy.zip . -x "*.pyc" "*/__pycache__/*" "tests/*" ".vscode/*" "pytest.log" ".git/*"

echo "Deploying to Azure..."
az webapp deployment source config-zip \
  --name document-generator-app \
  --resource-group rg-made-experiments \
  --src deploy.zip

echo "Cleaning up..."
rm deploy.zip

echo "Deployment complete! Check logs with:"
echo "az webapp log tail --name document-generator-app --resource-group rg-made-experiments"